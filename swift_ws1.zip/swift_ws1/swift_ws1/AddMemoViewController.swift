//
//  AddMemoViewController.swift
//  swift_ws1
//
//  Created by 19247019 on 2020/07/09.
//  Copyright © 2020 19247019. All rights reserved.
//

import UIKit

class AddMemoViewController: UIViewController {

    @IBOutlet weak var memoTextView: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func save(_ sender: Any) {
        self.memoTextView.resignFirstResponder()
        let inputText = memoTextView.text
        let ud = UserDefaults.standard
        if ud.array(forKey: "memoArray") != nil{
            var saveMemoArray = ud.array(forKey: "memoArray") as! [String]
            if inputText != ""{
                saveMemoArray.append(inputText!)
                ud.set(saveMemoArray,forKey: "memoArray")
            }else{
                showAlert(title:"内容が確認出来ません")
            }
        }
        showAlert(title:"保存されました")
        ud.synchronize()
    }
    func showAlert(title:String){
        let alert = UIAlertController(title: title, message: nil, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title:"OK",style: .default,handler: nil))
        alert.addAction(UIAlertAction(title:"キャンセル",style: .cancel,handler: nil))
        self.present(alert,animated: true, completion: nil)
    }
}
